from setuptools import setup, find_packages

setup(
    name='mi_aplicacion',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'flask',  # Dependencias de tu aplicación
        # Otras dependencias aquí
    ],
)
