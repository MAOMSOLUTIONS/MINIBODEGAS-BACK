import os

SECRET_KEY = 'tu_clave_secreta'  # Configura tu clave secreta aquí
